# Pokemon TS

## Project Structure

### src

Contains Typescript code.

### assets

Contains miscellaneous assets required for function.

### dist

Contains the compiled JavaScript that is then ran.

## Supported Pokémon

- Venusaur
- Charizard
- Blastoise
- Butterfree
- Beedrill
- Pidgeot
- Raticate
- Fearow
- Arbok
- Raichu
- Sandslash
- Nidoqueen

More to be added later!

hosted on cloudflare pages at
https://pokemon-ts.pages.dev